# Suivi des temps de natation

Site statique de suivi des performances de natation : records personnels, progression, meilleurs temps par âge et historique des compétitions.

## Fichiers

- `index.html` : le site (affichage et calculs). Pas besoin d'y toucher.
- `selection.html` : le classement de la sélection U12 benjamin (règles dans `SELECTION_U12`, dans `donnees.js`).
- `donnees.js` : les nageurs, les temps saisis à la main et les réglages (grille des départementaux, webconfrontation). **C'est le seul fichier à modifier à la main.**
- `donnees-ffn.js` : courses récupérées automatiquement sur les fiches FFN. Ne pas le modifier.
- `scripts/maj_ffn.py` et `.github/workflows/maj-ffn.yml` : la mise à jour automatique.

## Ajouter un temps

Dans `donnees.js`, copier une ligne de `PERFORMANCES`, la coller à la fin de la liste et changer les valeurs :

```js
{ nageur: "luka", date: "2026-12-06", epreuve: "100 Dos", temps: "1:37.80", points: 310, bassin: 25, lieu: "THIONVILLE", niveau: "REG" },
```

L'âge, la saison, les records et la progression sont recalculés automatiquement.

## Mise en ligne avec GitHub Pages

1. Créer un dépôt et y déposer `index.html` et `donnees.js`.
2. Dans **Settings > Pages**, choisir la branche `main` et le dossier `/ (root)`.
3. Le site est disponible à l'adresse `https://<identifiant>.github.io/<nom-du-depot>/`.

Le site fonctionne aussi en local, en ouvrant `index.html` dans un navigateur.

## Mise à jour automatique depuis la FFN

Chaque lundi à 6 h (UTC), GitHub lit la fiche FFN de chaque nageur qui a un numéro `iuf` dans `donnees.js`, et ajoute ses nouvelles courses dans `donnees-ffn.js`.

- Pour lancer la mise à jour à la main : onglet **Actions** > « Mise à jour depuis la FFN » > **Run workflow**.
- Si l'Action échoue avec une erreur de droits : **Settings > Actions > General > Workflow permissions**, cocher « Read and write permissions ».

## Ajouter un concurrent

Ajouter une ligne dans `NAGEURS` avec un `id` unique et son numéro FFN (`iuf`) :

```js
{ id: "nom-prenom", nom: "NOM", prenom: "Prénom", naissance: 2015, club: "Club", iuf: 1234567 },
```

Ses courses arriveront à la prochaine mise à jour automatique.
